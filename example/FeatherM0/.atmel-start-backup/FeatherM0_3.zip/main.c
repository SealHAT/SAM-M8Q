#include <atmel_start.h>
#include "usb_start.h"
#include "Utilities/seal_UTIL.h"
//8#include "gps.h"

int main(void)
{
	/* Initializes MCU, drivers and middleware */
// 	gpio_toggle_pin_level(DBG);
// 	delay_ms(100);
// 	gpio_toggle_pin_level(DBG);
	
	i2c_unblock_bus(SDA,SCL);
	atmel_start_init();

	//     if (gps_init_i2c(&I2C_DEV)) {
	//         gpio_toggle_pin_level(LED_BUILTIN);
	//     }

	for (;;)
	{
		gpio_toggle_pin_level(DBG);
		gpio_toggle_pin_level(LED_BUILTIN);
		delay_ms(200);
		
	}
}
